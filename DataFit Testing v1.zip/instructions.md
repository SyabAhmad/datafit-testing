## Testing Datafit : `v1`

### Author

 Tested By: `Syed Syab`
 
----

### Time and data

 date of testing : `Monday, February, 26, 2024`

 python version : `Python 3.9.0`

 Operating System : `Windows 10`

 Language ; `English`

----

### Data Description

 Data Format : `csv (comma separated values)`

 Data Description : `Protein Data`

----

### Test Cases
 Comming Soon